# Capston-Little-Lemon
Full-stack development for a store called Little-Lemon
